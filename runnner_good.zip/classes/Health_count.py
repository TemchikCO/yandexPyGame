import pygame
from pygame.sprite import Sprite

import data
from classes.FinishButton import finish_button


class Health_count(Sprite):
    def __init__(self, group):
        super(Health_count, self).__init__()
        self.group = group
        self.health = 1
        self.image1 = data.load_image("heart.png", -1)
        self.image = pygame.transform.scale(self.image1, (20, 20))

    def draw(self, screen):
        font = pygame.font.Font(None, 30)
        text = font.render(f"Ваши жизни:", True, 'black')
        text2 = font.render(f"{self.health}", True, 'red')
        text_x = text.get_width() // 6
        text_y = text.get_height() // 2
        screen.blit(text, (text_x, text_y))
        screen.blit(text2, (text_x + 135, text_y))
        screen.blit(self.image, (text_x + 157, text_y))

    def update(self, ms, health):
        if not finish_button.finish:
            self.health = health[2]
