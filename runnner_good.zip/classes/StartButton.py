import pygame

import data
from classes.StartSprite import StartSprite


class StartButton(StartSprite):
    def __init__(self, group, surface, x, y):
        super().__init__(group, surface, x, y)
        self.button_pressed = False
        self.text = f"Начать игру"

    def check_click(self, pos):
        if self.rect.topleft[0] <= pos[0] <= self.rect.bottomright[0]:
            if self.rect.topleft[1] <= pos[1] <= self.rect.bottomright[1]:
                self.button_pressed = True

    def update(self, ms):
        self.y += self.dir_y * ms / 1000
        if self.button_pressed:
            self.dir_y = self.speed

    def draw(self, screen):
        self.rect.topleft = self.x, self.y
        screen.blit(self.image, self.rect)
        font = pygame.font.Font('data/Kashima.ttf', 65)
        text = font.render(self.text, True, (0, 155, 255))
        screen.blit(text, (self.x + 42, self.y + 28))


start_button_image1 = data.load_image("another_button.png", -1)
start_button_image = pygame.transform.scale(start_button_image1, (408, 109))
start_button = StartButton(data.all_sprites, start_button_image, 390, 530)
start_button.add(data.start_sprites)
