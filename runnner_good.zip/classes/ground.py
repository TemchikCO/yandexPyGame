from classes.StartSprite import StartSprite


class Ground(StartSprite):
    def __init__(self, group, surface, x, y):
        super().__init__(group, surface, x, y)
        self.speed = 500

    def update(self, ms, horizontal, down_flag):
        self.speed += ms // 1000
        if not down_flag:
            self.x -= (self.speed * ms / 1000 + horizontal * self.speed * ms / 2000)
        else:
            self.x -= self.speed * ms / 1000
        if self.x <= -1199:
            self.x = 1200
