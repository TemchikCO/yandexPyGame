import pygame
import os
pygame.init()
size = 1200, 700
pygame.mouse.set_visible(False)
gravity = 9.81
final_sprites = pygame.sprite.Group()
all_sprites = pygame.sprite.Group()
clouds = pygame.sprite.Group()
start_sprites = pygame.sprite.Group()
play_sprites = pygame.sprite.Group()
trees = pygame.sprite.Group()
screen = pygame.display.set_mode(size)


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname).convert()
    except pygame.error as massage:
        print(f"Файл с изображением '{name}' не найден")
        raise SystemExit(massage)
    if colorkey:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image
#
# def load_image(name, colorkey=None):
#     fullname = os.path.join('data', name)
#     # если файл не существует, то выходим
#     if not os.path.isfile(fullname):
#         print(f"Файл с изображением '{fullname}' не найден")
#         test_surface = pygame.Surface([100, 100])
#         test_surface.fill(pygame.Color("red"))
#         return test_surface
#     image = pygame.image.load(fullname)
#     if colorkey:
#         image = image.convert()
#         if colorkey == -1:
#             colorkey = image.get_at((0, 0))
#         image.set_colorkey(colorkey)
#     else:
#         image = image.convert_alpha()
#     return image
