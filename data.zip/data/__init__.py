from sys import path

import pygame
import os
from classes.ground import Ground

pygame.init()
size = 1200, 700
pygame.mouse.set_visible(False)
gravity = 9.81
final_sprites = pygame.sprite.Group()
all_sprites = pygame.sprite.Group()
clouds = pygame.sprite.Group()
start_sprites = pygame.sprite.Group()
play_sprites = pygame.sprite.Group()
trees = pygame.sprite.Group()
ground = pygame.sprite.Group()
upgrade_buttons = pygame.sprite.Group()
screen = pygame.display.set_mode(size)
bowleds = pygame.sprite.Group()

lets = pygame.sprite.Group()
birds = pygame.sprite.Group()


def load_image(name, color_key=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname).convert()
    except pygame.error as massage:
        print(f"Файл с изображением '{name}' не найден")
        raise SystemExit(massage)
    if color_key:
        image = image.convert()
        if color_key == -1:
            color_key = image.get_at((0, 0))
        image.set_colorkey(color_key)
    else:
        image = image.convert_alpha()
    return image


immovablelet = pygame.transform.scale(load_image('Lets/kacktus.jpg', -1), (50, 60))
immovablelet_1 = pygame.transform.scale(load_image('Lets/stone_2.jpg', -1), (60, 55))
immovablelet_2 = pygame.transform.scale(load_image('Lets/stone_3.jpg', -1), (100, 50))
immovablelets = [immovablelet, immovablelet_1, immovablelet_2]

ground_image1 = load_image("Ground.jpg")
ground_image = pygame.transform.scale(ground_image1, (1300, 700))
ground1 = Ground(all_sprites, ground_image, 0, 400)
ground2 = Ground(all_sprites, ground_image, 1200, 400)
ground1.add(ground)
ground1.add(start_sprites)
ground2.add(ground)
ground2.add(start_sprites)

image_bird = pygame.transform.scale(load_image("many_bird.png", -1), (400, 400))

image_bowled1 = load_image("Bowleds/1.png", -1)
image_bowled = pygame.transform.scale(image_bowled1, (30, 30))


menu_music = 'data/music/marchofthespoons.mp3'
game_music = ['data/music/baseafterbase.mp3', 'data/music/xstep.mp3']

expl_sounds = []
for snd in ['5-gta-wasted', '0x01be5440', '413_money', 'bird-05-flying']:
    expl_sounds.append(pygame.mixer.Sound('data/music/' + snd + '.mp3'))

