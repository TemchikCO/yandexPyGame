import pygame
import os

from classes.FinishButton import FinishButton
from classes.StartButton import StartButton
from classes.StartSprite import StartSprite

pygame.init()
size = 1200, 700
pygame.mouse.set_visible(False)
gravity = 9.81
final_sprites = pygame.sprite.Group()
all_sprites = pygame.sprite.Group()
clouds = pygame.sprite.Group()
start_sprites = pygame.sprite.Group()
play_sprites = pygame.sprite.Group()
trees = pygame.sprite.Group()
screen = pygame.display.set_mode(size)

lets = pygame.sprite.Group()


def load_image(name, color_key=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname).convert()
    except pygame.error as massage:
        print(f"Файл с изображением '{name}' не найден")
        raise SystemExit(massage)
    if color_key:
        image = image.convert()
        if color_key == -1:
            color_key = image.get_at((0, 0))
        image.set_colorkey(color_key)
    else:
        image = image.convert_alpha()
    return image


immovablelet = pygame.transform.scale(load_image('Lets/stone.jpg', -1), (200, 150))

ground_image1 = load_image("Ground.jpg")
ground_image = pygame.transform.scale(ground_image1, (1200, 700))
ground = StartSprite(all_sprites, ground_image, 0, 400)
ground.add(start_sprites)

finish_button_image1 = load_image("start_button.png", -1)
finish_button_image = pygame.transform.scale(finish_button_image1, (204, 55))
finish_button = FinishButton(all_sprites, finish_button_image, 100, 530)
finish_button.add(start_sprites)

start_button_image1 = load_image("start_button.png", -1)
start_button_image = pygame.transform.scale(start_button_image1, (408, 109))
start_button = StartButton(all_sprites, start_button_image, 390, 530)
start_button.add(start_sprites)
