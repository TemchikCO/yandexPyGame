import pygame

from classes.StartButton import StartButton, start_button
import data


class UpgradeButton(StartButton):
    def __init__(self, group, surface, x, y):
        super().__init__(group, surface, x, y)
        self.upgrade_flag = False
        self.text = f'прокачка персонажа'
        self.update_count = 0

    def check_click(self, pos):
        if self.rect.topleft[0] <= pos[0] <= self.rect.bottomright[0]:
            if self.rect.topleft[1] <= pos[1] <= self.rect.bottomright[1]:
                self.upgrade_flag = True
                self.update_count += 1
                data.sounds[5].play()

    def update(self, ms):
        self.y += self.dir_y * ms / 1000
        if start_button.button_pressed:
            self.dir_y = self.speed

    def draw(self, screen):
        self.rect.topleft = self.x, self.y
        screen.blit(self.image, self.rect)
        font = pygame.font.Font('data/Kashima.ttf', 43)
        text = font.render(self.text, True, (0, 155, 255))
        screen.blit(text, (self.x + 31, self.y + 36))
