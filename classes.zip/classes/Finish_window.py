from pygame.sprite import Sprite
from data import finish_button


class Finish_window(Sprite):
    def __init__(self, group, surface, x, y):
        if group:
            super().__init__(group)
        else:
            super().__init__()
        self.image = surface
        self.rect = surface.get_rect()
        self.x: float = x
        self.y: float = y
        self.speed = 1500
        self.dir_y: float = 0
        self.final_y_position = 0

    def update(self, ms):
        self.y += self.dir_y * ms / 1000
        if finish_button and self.y < self.final_y_position:
            self.dir_y = self.speed
        else:
            self.dir_y = 0

    def draw(self, screen):
        self.rect.topleft = self.x, self.y
        screen.blit(self.image, self.rect)
