from pygame.sprite import Sprite
import pygame
from classes.FinishButton import finish_button


class Finish_window(Sprite):
    def __init__(self, group, surface, x, y):
        if group:
            super().__init__(group)
        else:
            super().__init__()
        self.image = surface
        self.rect = surface.get_rect()
        self.x: float = x
        self.y: float = y
        self.speed = 1500
        self.dir_y: float = 0
        self.final_y_position = 0
        self.final_y_text_position = 150
        self.text = f"Вы проиграли и попали в Россию"
        self.text_x = 300
        self.text_y = -550

    def update(self, ms):
        self.y += self.dir_y * ms / 1000
        self.text_y += self.dir_y * ms / 1000
        if finish_button.finish and self.y < self.final_y_position:
            self.dir_y = self.speed
        else:
            self.dir_y = 0
            self.y = 0

    def draw(self, screen, record, count):
        self.rect.topleft = self.x, self.y
        screen.blit(self.image, self.rect)
        font = pygame.font.Font(None, 50)
        text = font.render(self.text, True, (153, 0, 255))
        text1 = font.render(self.text, True, 'black')
        count_text = font.render(f'Вы набрали: {str(count)} очков', True, (153, 0, 255))
        count_text1 = font.render(f'Вы набрали: {str(count)} очков', True, 'black')
        if count >= record[0]:
            record_text = font.render(f'Вы установили новый рекорд!!!', True, (153, 0, 255))
            record_text1 = font.render(f'Вы установили новый рекорд!!!', True, 'black')
            record_text_x = self.text_x + 60
        else:
            record_text = font.render(f'Вам не хватило до рекорда рекорд: {str(record[0] - count)}',
                                      True, (153, 0, 255))
            record_text1 = font.render(f'Вам не хватило до рекорда рекорд: {str(record[0] - count)}', True, 'black')
            record_text_x = self.text_x
        money_text = font.render(f'Ваши деньги: {str(record[1])}', True, (153, 0, 255))
        money_text1 = font.render(f'Ваши деньги: {str(record[1])}', True, 'black')
        screen.blit(text1, (self.text_x - 3, self.text_y - 47))
        screen.blit(text, (self.text_x, self.text_y - 50))
        screen.blit(record_text1, (record_text_x - 53, self.text_y + 3))
        screen.blit(record_text, (record_text_x - 50, self.text_y))
        screen.blit(money_text1, (self.text_x + 117, self.text_y + 53))
        screen.blit(money_text, (self.text_x + 120, self.text_y + 50))
        screen.blit(count_text1, (self.text_x + 102, self.text_y + 103))
        screen.blit(count_text, (self.text_x + 105, self.text_y + 100))
