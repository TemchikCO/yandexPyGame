import pygame

import data
from classes.Imovablet import ImmovableLet


class Boss(ImmovableLet):
    def __init__(self, y, speed):
        self.hp = int(speed // 50)
        self.frames = []
        self.cut_sheet(data.boss, 12, 5)
        self.cur_frame = 0
        self.image = self.frames[self.cur_frame]
        super().__init__(speed, self.image)
        self.y = y
        self.rect = self.rect.move(self.x, y)
        self.upgrades_per_frame = 20
        self.upgrades_count = 0
        self.image1 = pygame.transform.scale(data.load_image("heart.png", -1), (20, 20))

    def cut_sheet(self, sheet, columns, rows):
        self.rect = pygame.Rect(0, 0, sheet.get_width() // columns,
                                sheet.get_height() // rows)
        for j in range(rows):
            for i in range(columns):
                frame_location = (self.rect.w * i, self.rect.h * j)
                self.frames.append(sheet.subsurface(pygame.Rect(
                    frame_location, self.rect.size)))

    def update(self, ms, speed, horizontal):
        super(Boss, self).update(ms, speed / 10, horizontal)
        self.upgrades_count += 1
        if self.upgrades_count == self.upgrades_per_frame:
            self.cur_frame = (self.cur_frame + 1) % len(self.frames)
            self.image = self.frames[self.cur_frame]
            self.upgrades_count = 0
        self.mask = pygame.mask.from_surface(self.image)

    def draw(self, screen):
        super(Boss, self).draw(screen)
        font = pygame.font.Font(None, 30)
        text = font.render(f"Здоровье", True, 'black')
        text2 = font.render(f"{self.hp}", True, 'red')
        text_x = text.get_width()
        text_x2 = text2.get_width()
        screen.blit(text, (self.x + 50, self.y))
        screen.blit(text2, (self.x + 50 + text_x, self.y))
        screen.blit(self.image1, (self.x + 50 + text_x2 + text_x, self.y))
