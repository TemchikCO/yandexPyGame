from pygame.sprite import Sprite
import pygame

import data
from classes.Cancel_button import Cancel_upgrade_button
from classes.Money_count import Money_count
from classes.Upgrade_button import Upgrade_button


class Upgrade_window(Sprite):
    def __init__(self, group, surface, x, y):
        if group:
            super().__init__(group)
        else:
            super().__init__()
        self.image = surface
        self.rect = surface.get_rect()
        self.x: float = x
        self.y: float = y
        self.speed = 2500
        self.dir_y: float = 0
        self.final_y_position = 500
        self.start_y_position = y

    def update(self, ms):
        self.y -= self.dir_y * ms / 1000
        if self.y > self.final_y_position and upgrade_button.update_count > cancel_upgrade_button.cancel_count:
            self.dir_y = self.speed
        else:
            if cancel_upgrade_button.cancel_count == upgrade_button.update_count:
                if self.y < self.start_y_position:
                    self.dir_y = -self.speed
                else:
                    self.dir_y = 0
            else:
                self.dir_y = 0

    def draw(self, screen):
        self.rect.topleft = self.x, self.y
        screen.blit(self.image, self.rect)
        font = pygame.font.Font('data/Kashima.ttf', 30)
        text_1 = font.render(f'max. жизней', True, 'yellow')
        text_2 = font.render(f'время перезарядки', True, 'yellow')
        text_3 = font.render(f'max. патронов', True, 'yellow')
        text_4 = font.render(f'урон от выстрелов', True, 'yellow')
        text_5 = font.render(f'счётчик очков', True, 'yellow')
        screen.blit(text_1, (self.x + 20, self.y + 25))
        screen.blit(text_2, (self.x + 200, self.y + 25))
        screen.blit(text_3, (self.x + 500, self.y + 25))
        screen.blit(text_4, (self.x + 720, self.y + 25))
        screen.blit(text_5, (self.x + 1000, self.y + 25))


upgrade_button_image1 = data.load_image("another_button.png", -1)
upgrade_button_image = pygame.transform.scale(upgrade_button_image1, (204, 55))
upgrade_button = Upgrade_button(data.all_sprites, upgrade_button_image, 1000, 530)
upgrade_button.add(data.start_sprites)

upgrade_window_image1 = data.load_image("upgrade_bg.jpg")
upgrade_window_image = pygame.transform.scale(upgrade_window_image1, (1200, 300))
upgrade_window = Upgrade_window(data.all_sprites, upgrade_window_image, 0, 700)
upgrade_window.add(data.final_sprites)

cancel_upgrade_button_image1 = data.load_image("cancel_upgrade_button.png", -1)
cancel_upgrade_button_image = pygame.transform.scale(cancel_upgrade_button_image1, (30, 30))
cancel_upgrade_button = Cancel_upgrade_button(data.all_sprites, cancel_upgrade_button_image, 1170, 700, upgrade_window)
cancel_upgrade_button.add(data.final_sprites)

money_count = Money_count(data.all_sprites, upgrade_window)
