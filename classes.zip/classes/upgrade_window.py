from pygame.sprite import Sprite
import pygame
from Upgrade_button import upgrade_button


class Upgrade_window(Sprite):
    def __init__(self, group, surface, x, y):
        if group:
            super().__init__(group)
        else:
            super().__init__()
        self.image = surface
        self.rect = surface.get_rect()
        self.x: float = x
        self.y: float = y
        self.speed = 3000
        self.dir_y: float = 0
        self.final_y_position = 350

    def update(self, ms):
        self.y += self.dir_y * ms / 1000
        if upgrade_button.upgrade_flag and self.y < self.final_y_position:
            self.dir_y = self.speed
        else:
            self.dir_y = 0
            self.y = 0

    def draw(self, screen):
        self.rect.topleft = self.x, self.y
        screen.blit(self.image, self.rect)
        font = pygame.font.Font(None, 50)
