import pygame

import data
from classes.StartButton import StartButton, start_button


class Upgrade_button(StartButton):
    def __init__(self, group, surface, x, y):
        super().__init__(group, surface, x, y)
        self.upgrade_flag = False
        self.text = f'прокачка персонажа'

    def check_click(self, pos):
        if self.rect.topleft[0] <= pos[0] <= self.rect.bottomright[0]:
            if self.rect.topleft[1] <= pos[1] <= self.rect.bottomright[1]:
                self.upgrade_flag = True

    def update(self, ms):
        self.y += self.dir_y * ms / 1000
        if self.upgrade_flag or start_button.button_pressed:
            self.dir_y = self.speed

    def draw(self, screen):
        self.rect.topleft = self.x, self.y
        screen.blit(self.image, self.rect)
        font = pygame.font.Font('data/Kashima.ttf', 21)
        text = font.render(self.text, True, (0, 155, 255))
        screen.blit(text, (self.x + 15, self.y + 20))


upgrade_button_image1 = data.load_image("another_button.png", -1)
upgrade_button_image = pygame.transform.scale(upgrade_button_image1, (204, 55))
upgrade_button = Upgrade_button(data.all_sprites, upgrade_button_image, 1000, 530)
upgrade_button.add(data.start_sprites)
