import pygame

import data
from data import start_sprites, clouds
from classes.StartSprite import StartSprite


class Cloud(StartSprite):
    def __init__(self, group, surface, x, y):
        super().__init__(group, surface, x, y)
        self.frames = []
        self.add(start_sprites)
        self.add(clouds)
        for i in range(12):
            animate_cloud_image1 = data.load_image(f'clouds/{i + 1}.png', -1)
            animate_cloud_image = pygame.transform.scale(animate_cloud_image1, (200, 150))
            self.frames.append(animate_cloud_image)
        self.upgrades_count = 1
        self.upgrades_per_frame = 3
        self.cur_frame = 0
        self.image = surface

    def update(self):
        self.upgrades_count += 1
        if self.upgrades_count == self.upgrades_per_frame:
            self.cur_frame = (self.cur_frame + 1) % len(self.frames)
            self.image = self.frames[self.cur_frame]
            self.upgrades_count = 0
