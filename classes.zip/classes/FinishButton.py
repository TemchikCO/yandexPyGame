from classes.StartButton import StartButton


class FinishButton(StartButton):
    def __init__(self, group, surface, x, y):
        super().__init__(group, surface, x, y)
        self.finish = False

    def check_click(self, pos):
        if self.rect.topleft[0] <= pos[0] <= self.rect.bottomright[0]:
            if self.rect.topleft[1] <= pos[1] <= self.rect.bottomright[1]:
                self.finish = True

    def update(self, ms):
        self.y += self.dir_y * ms / 1000
        if self.finish:
            self.dir_y = self.speed