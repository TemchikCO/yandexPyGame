from classes.StartSprite import StartSprite
from data import start_button


class Avatar(StartSprite):
    def update(self, ms):
        self.y += self.dir_y * ms / 1000
        if start_button.button_pressed:
            self.dir_y = -self.speed