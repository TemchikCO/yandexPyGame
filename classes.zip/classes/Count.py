import pygame
from pygame.sprite import Sprite
from classes.Button_for_upgrade import Count_upgrade_button
from classes.FinishButton import finish_button


class Count(Sprite):
    def __init__(self, group):
        super(Count, self).__init__()
        self.time = 0
        self.group = group
        self.count = 0
        self.koef = Count_upgrade_button.smth
        self.money_update = 0
        self.plus = 0

    def draw(self, screen):
        font = pygame.font.Font(None, 50)
        text = font.render(f"{int(self.count)}", True, 'black')
        text_x = 1100 - text.get_width() // 2
        text_y = text.get_height() // 2
        screen.blit(text, (text_x, text_y))

    def update(self, ms, koef):
        if not finish_button.finish:
            self.plus += 0.0005
            self.koef = koef + self.plus
            self.time += ms
            self.count = round(self.time * self.koef)
