import pygame

import data
from data import lets, bowleds


def chek(i, player, finish, health_count, to_kill, boss=False):
    if pygame.sprite.collide_mask(i, player):
        to_kill.append(i)
        health_count.health -= 1
        data.sounds[9].play()
        if health_count.health < 1 or boss:
            finish.finish = True
            data.sounds[0].play()
            pygame.mixer.music.stop()


def chek_lets(player, finish, health_count, inf, boss_flag):
    to_kill = []
    damage = int(inf[3][0])
    for i in lets:
        chek(i, player, finish, health_count, to_kill)
    for i in data.birds:
        chek(i, player, finish, health_count, to_kill)
    for i in data.boss_group:
        chek(i, player, finish, health_count, to_kill, boss=True)
    for bullet in bowleds:
        for j in data.birds:
            if pygame.sprite.collide_mask(bullet, j):
                to_kill.append(j)
                to_kill.append(bullet)
                data.sounds[4].play()

        for i in lets:
            if bullet.rect.colliderect(i.rect):
                to_kill.append(bullet)

        for i in data.boss_group:
            if pygame.sprite.collide_mask(bullet, i):
                bullet.kill()
                i.hp -= damage
                if i.hp < 0:
                    i.kill()
                    boss_flag.boss = False
    for i in to_kill:
        i.kill()