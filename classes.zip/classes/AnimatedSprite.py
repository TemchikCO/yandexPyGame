import pygame

import data
from classes.StartSprite import StartSprite


class AnimatedSprite(StartSprite):
    def __init__(self, group, surface, x, y, file_name):
        super().__init__(group, surface, x, y)
        self.frames = []
        self.file_name = file_name
        self.count = 15
        for i in range(self.count):
            animate_hero_image1 = data.load_image(f'{self.file_name}\{i + 1}.png', -1)
            animate_hero_image = pygame.transform.scale(animate_hero_image1, (96, 111))
            self.frames.append(animate_hero_image)
        self.upgrades_count = 1
        self.upgrades_per_frame = 6
        self.cur_frame = 0
        self.image = surface

    def update(self):
        self.upgrades_count += 1
        if self.upgrades_count == self.upgrades_per_frame:
            self.cur_frame = (self.cur_frame + 1) % len(self.frames)
            self.image = self.frames[self.cur_frame]
            self.upgrades_count = 0

