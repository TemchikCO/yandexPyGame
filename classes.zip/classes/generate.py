import random

import data
from classes.Imovablet import ImmovableLet
from classes.bird_let import Bird
from classes.boss import Boss
from data import lets


class Generate:
    def __init__(self):
        self.total_ms = 0
        self.boss = False

    def do(self, ms, speed, score):
        self.total_ms += ms
        if self.total_ms >= 100000 / speed * 4:
            self.total_ms = 0
            if random.choice([True, True, False]):
                lets.add(ImmovableLet(speed, random.choice(data.immovablelets)))
            elif score > 2000 and random.choice([True, False]):
                data.birds.add(Bird(random.choice([340, 249, 280]), speed))
            if not self.boss and score > 10000:
                data.boss_group.add(Boss(300, speed))
                self.boss = True