import pygame

from classes.StartSprite import StartSprite
from data import lets


class ImmovableLet(StartSprite):
    def __init__(self, speed, image):
        super().__init__(None, image, 1300, 482 - image.get_height())
        self.mask = pygame.mask.from_surface(self.image)
        self.speed = speed

    def update(self, ms, speed):
        self.x -= speed * ms / 1000

    def draw(self, screen):
        self.rect.topleft = self.x, self.y
        screen.blit(self.image, self.rect)
        if self.x < 0 - self.rect.width:
            self.kill()
