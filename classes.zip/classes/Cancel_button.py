from pygame.sprite import Sprite


class Cancel_upgrade_button(Sprite):
    def __init__(self, group, surface, x, y, parent):
        if group:
            super().__init__(group)
        else:
            super().__init__()
        self.upgrade_window = parent
        self.image = surface
        self.rect = surface.get_rect()
        self.x: float = x
        self.y: float = y
        self.speed = 2500
        self.dir_y: float = 0
        self.final_y_position: float = 500
        self.start_y_position = y
        self.cancel_upgrade_flag = False
        self.cancel_count = 0

    def check_click(self, pos):
        if self.rect.topleft[0] <= pos[0] <= self.rect.bottomright[0]:
            if self.rect.topleft[1] <= pos[1] <= self.rect.bottomright[1]:
                self.cancel_upgrade_flag = True
                self.cancel_count += 1

    def draw(self, screen):
        self.y = self.upgrade_window.rect.topright[1]
        self.rect.topleft = self.x, self.y
        screen.blit(self.image, self.rect)
