import pygame

import data
from classes.Imovablet import ImmovableLet


class Bird(ImmovableLet):
    def __init__(self, y, speed):
        self.frames = []
        self.cut_sheet(data.image_bird, 8, 3)
        self.cur_frame = 0
        self.image = self.frames[self.cur_frame]
        super().__init__(speed, self.image)
        self.y = y
        self.rect = self.rect.move(self.x, y)
        self.upgrades_per_frame = 20
        self.upgrades_count = 0

    def cut_sheet(self, sheet, columns, rows):
        self.rect = pygame.Rect(0, 0, sheet.get_width() // columns,
                                sheet.get_height() // rows)
        for j in range(rows):
            for i in range(columns):
                frame_location = (self.rect.w * i, self.rect.h * j)
                self.frames.append(sheet.subsurface(pygame.Rect(
                    frame_location, self.rect.size)))

    def update(self, ms, speed):
        super(Bird, self).update(ms, speed)
        self.upgrades_count += 1
        if self.upgrades_count == self.upgrades_per_frame:
            self.cur_frame = (self.cur_frame + 1) % len(self.frames)
            self.image = self.frames[self.cur_frame]
            self.upgrades_count = 0
        self.mask = pygame.mask.from_surface(self.image)