import pygame
from pygame.sprite import Sprite

import data


class Money_count(Sprite):
    def __init__(self, group, parent):
        super(Money_count, self).__init__()
        self.group = group
        self.image1 = data.load_image("coin.png", -1)
        self.image = pygame.transform.scale(self.image1, (20, 20))
        self.x = 0
        self.y = 700
        self.upgrade_window = parent

    def draw(self, screen, info_list):
        self.x, self.y = self.upgrade_window.rect.topleft
        font = pygame.font.Font(None, 30)
        text = font.render(f"Ваши деньги:", True, 'white')
        text2 = font.render(f"{info_list[1]}", True, 'yellow')
        screen.blit(text, (self.x, self.y))
        screen.blit(text2, (self.x + 140, self.y))
