import pygame
from pygame.sprite import Sprite

import data
from classes.StartSprite import StartSprite


class Bowled(StartSprite):
    def __init__(self, group, surface, x, y, parent):
        super().__init__(group, surface, x, y)
        self.frames = []
        self.speed = 1500
        self.add(group)
        self.parent = parent
        for i in range(4):
            animate_bowled_image1 = data.load_image(f'Bowleds/{i + 1}.png', -1)
            animate_bowled_image = pygame.transform.scale(animate_bowled_image1, (30, 30))
            self.frames.append(animate_bowled_image)
        self.upgrades_count = 1
        self.upgrades_per_frame = 6
        self.cur_frame = 0
        self.image = surface
        self.y = self.parent.rect.topleft[1]
        self.bowlet_count = control.max_bowlet_count

    def draw(self, screen):
        screen.blit(self.image, (self.x + 80, self.y + 30))

    def update(self, ms):
        self.upgrades_count += 1
        self.speed += ms // 1000
        if self.upgrades_count == self.upgrades_per_frame:
            self.cur_frame = (self.cur_frame + 1) % len(self.frames)
            self.image = self.frames[self.cur_frame]
            self.upgrades_count = 0
        self.x += self.speed * ms / 1000
        if self.x >= 1200:
            self.kill()


class Control(Sprite):
    def __init__(self, group):
        super(Control, self).__init__()
        self.group = group
        self.health = 1
        self.image1 = data.load_image("heart.png", -1)
        self.image = pygame.transform.scale(self.image1, (20, 20))
        self.max_bowlet_count = 4
        self.relouding_time = 6
        self.acept_fire = True
        self.bowlet_count = 0
        self.time_left = 0

    def update(self, information, ms):
        self.max_bowlet_count = int(information[5][0])
        self.relouding_time = int(information[6][0])
        self.time_left += ms / 1000
        if self.time_left >= self.relouding_time and self.bowlet_count >= 1:
            self.bowlet_count -= 1
            self.time_left = 0
        if self.max_bowlet_count > self.bowlet_count:
            self.acept_fire = True
        else:
            self.acept_fire = False

    def draw(self, screen):
        font = pygame.font.Font(None, 30)
        text = font.render(f"Пули:{self.bowlet_count}/{self.max_bowlet_count}", True, 'black')
        screen.blit(text, (220, 10))


control = Control(data.start_sprites)
