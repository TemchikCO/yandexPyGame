import pygame

import data
from classes.StartSprite import StartSprite


class RanHero(StartSprite):
    def __init__(self, group, surface, x, y, filename):
        super().__init__(group, surface, x, y)
        self.dir_x: float = 0
        self.ranning_frames_forward = []
        self.jumping_frames_forward = []
        self.ranning_frames_back = []
        self.jumping_frames_back = []
        self.down_frames = []
        self.active_frames = []
        self.jump_force = 150
        self.down_flag = False
        self.can_jump = True
        for i in range(8):
            animate_ran_hero_image1 = data.load_image(f'{filename}/{i + 1}.png', -1)
            animate_ran_hero_image = pygame.transform.scale(animate_ran_hero_image1, (96, 111))
            self.ranning_frames_forward.append(animate_ran_hero_image)
        for i in range(4):
            animate_jump_hero_image1 = data.load_image(f'jumping_hero/{i + 1}.png', -1)
            animate_jump_hero_image = pygame.transform.scale(animate_jump_hero_image1, (96, 111))
            self.jumping_frames_forward.append(animate_jump_hero_image)
        for i in range(8):
            animate_ran_hero_image1 = data.load_image(f'{filename}_mirred/{i + 1}.png', -1)
            animate_ran_hero_image = pygame.transform.scale(animate_ran_hero_image1, (96, 111))
            self.ranning_frames_back.append(animate_ran_hero_image)
        for i in range(4):
            animate_jump_hero_image1 = data.load_image(f'jumping_hero_mirred/{i + 1}.png', -1)
            animate_jump_hero_image = pygame.transform.scale(animate_jump_hero_image1, (96, 111))
            self.jumping_frames_back.append(animate_jump_hero_image)
        for i in range(3):
            animate_down_hero_image1 = data.load_image(f'down_hero/{i + 1}.png', -1)
            animate_down_hero_image = pygame.transform.scale(animate_down_hero_image1, (96, 111))
            self.down_frames.append(animate_down_hero_image)
        self.upgrades_count = 1
        self.upgrades_per_frame = 7
        self.cur_frame = 0
        self.image = surface
        self.mask = pygame.mask.from_surface(self.image)

    def update(self, ms, speed):
        self.upgrades_per_frame = speed // 72
        self.upgrades_count += 1
        if self.upgrades_count == self.upgrades_per_frame:
            if self.is_grounded():
                if self.down_flag:
                    self.active_frames = self.down_frames.copy()
                    self.y = 390
                else:
                    self.y = 370
                    if self.dir_x >= 0:
                        self.active_frames = self.ranning_frames_forward.copy()
                    else:
                        self.active_frames = self.ranning_frames_back.copy()
                self.cur_frame = (self.cur_frame + 1) % len(self.active_frames)
                self.image = self.active_frames[self.cur_frame]
            elif not self.is_grounded():
                if self.dir_x >= 0:
                    self.active_frames = self.jumping_frames_forward.copy()
                else:
                    self.active_frames = self.jumping_frames_back.copy()
                self.cur_frame = (self.cur_frame + 1) % len(self.active_frames)
                self.image = self.active_frames[self.cur_frame]
            self.upgrades_count = 0
        self.x += self.dir_x * ms / 1000
        if self.x <= 0:
            self.x -= self.dir_x * ms / 1000
        if self.x >= 1100:
            self.x -= self.dir_x * ms / 1000

        self.y += self.dir_y * ms / 200
        if self.is_grounded():
            self.dir_y = 0
            self.can_jump = True
        else:
            self.can_jump = False
            self.dir_y += data.gravity * ms / 15

    def is_grounded(self):
        return self.y > 370

    def set_move(self, horizontal):
        if not self.down_flag:
            self.dir_x = horizontal * self.speed
        else:
            self.dir_x = 0

    def jump(self):
        if self.can_jump:
            self.dir_y = -self.jump_force
