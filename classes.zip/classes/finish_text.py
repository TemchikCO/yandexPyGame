import pygame

from classes.Finish_window import Finish_window


class Finish_text(Finish_window):
    def __init__(self, group, surface, x, y):
        super().__init__(group, surface, x, y)
        self.final_y_position = 150
        self.text = f"Вы проиграли и попали в Россию"

    def draw(self, screen, record, count):
        font = pygame.font.Font(None, 50)
        text = font.render(self.text, True, 'green')
        count_text = font.render(f'Вы набрали: {str(count)} очков', True, 'green')
        if count >= record[0]:
            record_text = font.render(f'Вы установили новый рекорд!!!', True, 'green')
        else:
            record_text = font.render(f'Вам не хватило до рекорда рекорд: {str(record[0] - count)}', True, 'green')
        money_text = font.render(f'Ваши деньги: {str(record[1])}', True, 'green')
        screen.blit(text, (self.x, self.y))
        screen.blit(count_text, (self.x + 170, self.y + 150))
        screen.blit(record_text, (self.x + 100, self.y + 70))
        screen.blit(money_text, (self.x + 170, self.y + 100))