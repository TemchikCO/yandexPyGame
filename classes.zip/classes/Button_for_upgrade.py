import pygame
from pygame.sprite import Sprite

import data
from classes.upgrade_window import upgrade_window
from classes.FinishButton import finish_button


class Button_for_upgrade(Sprite):
    def __init__(self, group, surface, x, y, parent, position):
        if group:
            super().__init__(group)
        else:
            super().__init__()
        self.add(group)
        self.upgrade_window = parent
        self.image = surface
        self.rect = surface.get_rect()
        self.x: float = x
        self.y: float = y
        self.speed = 2500
        self.dir_y: float = 0
        self.final_y_position: float = 600
        self.start_y_position = y
        self.try_upgrade_smth = False
        self.upgrade_smth = False
        self.text = 'Прокачать'
        self.smth = 0
        self.position = position
        self.cost = 1000
        self.level = 0

    def check_click(self, pos):
        if self.rect.topleft[0] <= pos[0] <= self.rect.bottomright[0]:
            if self.rect.topleft[1] <= pos[1] <= self.rect.bottomright[1]:
                self.try_upgrade_smth = True


    def update(self, information):
        self.cost = self.level * 1000
        self.level = int(information[self.position][1][:-1])
        self.smth = float(information[self.position][0])
        if self.try_upgrade_smth:
            if information[1] >= self.cost and self.level <= 9:
                if self.position == 6:
                    if self.smth > 1:
                        self.cost += 1000
                        self.upgrade_smth = True
                else:
                    self.cost += 1000
                    self.upgrade_smth = True
                    data.sounds[7].play()
        self.try_upgrade_smth = False

    def draw(self, screen):
        if not finish_button.button_pressed:
            self.y = self.upgrade_window.rect.topleft[1]
            self.rect.topleft = self.x, self.y + 80
            font = pygame.font.Font('data/Kashima.ttf', 25)
            text = font.render(self.text, True, 'white')
            cost_text = font.render(f'стоимость:{self.cost}', True, 'yellow')
            level_text = font.render(f'уровень:{self.level}/10', True, 'yellow')
            if self.position == 2:
                value_text = font.render(f'Кол-во жизней:{self.smth}', True, 'yellow')
                screen.blit(value_text, (self.x, self.y + 140))
            elif self.position == 3:
                value_text = font.render(f'Урон:{self.smth}', True, 'yellow')
                screen.blit(value_text, (self.x + 40, self.y + 140))
            elif self.position == 4:
                value_text = font.render(f'Множитель очков:{self.smth}X', True, 'yellow')
                screen.blit(value_text, (self.x - 20, self.y + 140))
            elif self.position == 5:
                value_text = font.render(f'Max. пуль:{self.smth}', True, 'yellow')
                screen.blit(value_text, (self.x + 20, self.y + 140))
            else:
                value_text = font.render(f'Время перезарядки:{self.smth}сек', True, 'yellow')
                screen.blit(value_text, (self.x - 10, self.y + 140))
            screen.blit(self.image, (self.x + 10, self.y + 80))
            screen.blit(text, (self.x + 30, self.y + 85))
            screen.blit(cost_text, (self.x + 10, self.y + 60))
            screen.blit(level_text, (self.x + 20, self.y + 120))


image1 = data.load_image("another_button.png", -1)
image = pygame.transform.scale(image1, (160, 35))
Health_button = Button_for_upgrade(data.upgrade_buttons, image, 0, 760, upgrade_window, 2)
Reload_time_button = Button_for_upgrade(data.upgrade_buttons, image, 250, 760, upgrade_window, 6)
Bowled_count_button = Button_for_upgrade(data.upgrade_buttons, image, 500, 760, upgrade_window, 5)
Damage_button = Button_for_upgrade(data.upgrade_buttons, image, 750, 760, upgrade_window, 3)
Count_upgrade_button = Button_for_upgrade(data.upgrade_buttons, image, 1000, 760, upgrade_window, 4)
