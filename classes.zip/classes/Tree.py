import pygame

import data
from data import start_sprites, trees
from classes.StartSprite import StartSprite


class Tree(StartSprite):
    def __init__(self, group, surface, x, y):
        super().__init__(group, surface, x, y)
        self.frames = []
        self.speed = 500
        self.add(start_sprites)
        self.add(trees)
        for i in range(20):
            animate_tree_image1 = data.load_image(f'tree_gif/{i + 1}.png', -1)
            animate_tree_image = pygame.transform.scale(animate_tree_image1, (200, 150))
            self.frames.append(animate_tree_image)
        self.upgrades_count = 1
        self.upgrades_per_frame = 6
        self.cur_frame = 0
        self.image = surface

    def update(self, ms, horizontal, down_flag):
        self.upgrades_count += 1
        self.speed += ms // 1000
        if self.upgrades_count == self.upgrades_per_frame:
            self.cur_frame = (self.cur_frame + 1) % len(self.frames)
            self.image = self.frames[self.cur_frame]
            self.upgrades_count = 0
        if not down_flag:
            self.x -= (self.speed * ms / 1000 + horizontal * self.speed * ms / 2000)
        else:
            self.x -= self.speed * ms / 1000
        if self.x <= -382:
            self.x = 1200