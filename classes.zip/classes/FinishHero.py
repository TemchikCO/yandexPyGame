from classes.AnimatedSprite import AnimatedSprite


class FinishHero(AnimatedSprite):
    def __init__(self, group, surface, x, y, file_name):
        super().__init__(group, surface, x, y, file_name)
        self.count = 2
        self.file_name = 5