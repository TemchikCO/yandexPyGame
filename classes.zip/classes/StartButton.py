from classes.StartSprite import StartSprite


class StartButton(StartSprite):
    def __init__(self, group, surface, x, y):
        super().__init__(group, surface, x, y)
        self.button_pressed = False

    def check_click(self, pos):
        if self.rect.topleft[0] <= pos[0] <= self.rect.bottomright[0]:
            if self.rect.topleft[1] <= pos[1] <= self.rect.bottomright[1]:
                self.button_pressed = True

    def update(self, ms):
        self.y += self.dir_y * ms / 1000
        if self.button_pressed:
            self.dir_y = self.speed